/*!
 * @name 聚合API接口 (by lerd)
 * @description 理论可听全平台无损
 * @version v2.0.0
 * @author lerd
 */
var _0xod2 = 'jsjiami.com.v7';
const _0x2375d4 = _0x332b;

function _0x332b(_0x1a7e99, _0x56212e) {
    const _0x3e5405 = _0x3e54();
    return _0x332b = function(_0x332b4b, _0x5de7c7) {
        _0x332b4b = _0x332b4b - 0x99;
        let _0x8b95dc = _0x3e5405[_0x332b4b];
        if (_0x332b['tRowSc'] === undefined) {
            var _0x16b257 = function(_0xacfc57) {
                const _0x48a39a = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';
                let _0x141f02 = '',
                    _0x43ba4a = '';
                for (let _0x386ddc = 0x0, _0x1e3707, _0x502bc7, _0x307a78 = 0x0; _0x502bc7 = _0xacfc57['charAt'](_0x307a78++); ~_0x502bc7 && (_0x1e3707 = _0x386ddc % 0x4 ? _0x1e3707 * 0x40 + _0x502bc7 : _0x502bc7, _0x386ddc++ % 0x4) ? _0x141f02 += String['fromCharCode'](0xff & _0x1e3707 >> (-0x2 * _0x386ddc & 0x6)) : 0x0) {
                    _0x502bc7 = _0x48a39a['indexOf'](_0x502bc7);
                }
                for (let _0x29b5ae = 0x0, _0x3431e8 = _0x141f02['length']; _0x29b5ae < _0x3431e8; _0x29b5ae++) {
                    _0x43ba4a += '%' + ('00' + _0x141f02['charCodeAt'](_0x29b5ae)['toString'](0x10))['slice'](-0x2);
                }
                return decodeURIComponent(_0x43ba4a);
            };
            const _0x2cb0ad = function(_0x3d4aa5, _0x1614ac) {
                let _0x53c089 = [],
                    _0xf29bb0 = 0x0,
                    _0x4c7be5, _0x267bb8 = '';
                _0x3d4aa5 = _0x16b257(_0x3d4aa5);
                let _0xee68a9;
                for (_0xee68a9 = 0x0; _0xee68a9 < 0x100; _0xee68a9++) {
                    _0x53c089[_0xee68a9] = _0xee68a9;
                }
                for (_0xee68a9 = 0x0; _0xee68a9 < 0x100; _0xee68a9++) {
                    _0xf29bb0 = (_0xf29bb0 + _0x53c089[_0xee68a9] + _0x1614ac['charCodeAt'](_0xee68a9 % _0x1614ac['length'])) % 0x100, _0x4c7be5 = _0x53c089[_0xee68a9], _0x53c089[_0xee68a9] = _0x53c089[_0xf29bb0], _0x53c089[_0xf29bb0] = _0x4c7be5;
                }
                _0xee68a9 = 0x0, _0xf29bb0 = 0x0;
                for (let _0x10de97 = 0x0; _0x10de97 < _0x3d4aa5['length']; _0x10de97++) {
                    _0xee68a9 = (_0xee68a9 + 0x1) % 0x100, _0xf29bb0 = (_0xf29bb0 + _0x53c089[_0xee68a9]) % 0x100, _0x4c7be5 = _0x53c089[_0xee68a9], _0x53c089[_0xee68a9] = _0x53c089[_0xf29bb0], _0x53c089[_0xf29bb0] = _0x4c7be5, _0x267bb8 += String['fromCharCode'](_0x3d4aa5['charCodeAt'](_0x10de97) ^ _0x53c089[(_0x53c089[_0xee68a9] + _0x53c089[_0xf29bb0]) % 0x100]);
                }
                return _0x267bb8;
            };
            _0x332b['FKfPGk'] = _0x2cb0ad, _0x1a7e99 = arguments, _0x332b['tRowSc'] = !![];
        }
        const _0x2ee30b = _0x3e5405[0x0],
            _0x4c3704 = _0x332b4b + _0x2ee30b,
            _0x5c20ff = _0x1a7e99[_0x4c3704];
        return !_0x5c20ff ? (_0x332b['tkWaPe'] === undefined && (_0x332b['tkWaPe'] = !![]), _0x8b95dc = _0x332b['FKfPGk'](_0x8b95dc, _0x5de7c7), _0x1a7e99[_0x4c3704] = _0x8b95dc) : _0x8b95dc = _0x5c20ff, _0x8b95dc;
    }, _0x332b(_0x1a7e99, _0x56212e);
}(function(_0x31e252, _0x31ec74, _0x501ac3, _0x475b9f, _0x230a89, _0x41e081, _0x32f175) {
    return _0x31e252 = _0x31e252 >> 0x6, _0x41e081 = 'hs', _0x32f175 = 'hs',
        function(_0x599cb1, _0x3eee44, _0x2c12af, _0x5a4750, _0x27ab7a) {
            const _0x34367f = _0x332b;
            _0x5a4750 = 'tfi', _0x41e081 = _0x5a4750 + _0x41e081, _0x27ab7a = 'up', _0x32f175 += _0x27ab7a, _0x41e081 = _0x2c12af(_0x41e081), _0x32f175 = _0x2c12af(_0x32f175), _0x2c12af = 0x0;
            const _0x554200 = _0x599cb1();
            while (!![] && --_0x475b9f + _0x3eee44) {
                try {
                    _0x5a4750 = -parseInt(_0x34367f(0xc3, 'OjpG')) / 0x1 * (-parseInt(_0x34367f(0xf1, 'AXG[')) / 0x2) + -parseInt(_0x34367f(0xac, 'OjpG')) / 0x3 + -parseInt(_0x34367f(0xa9, 'rxWY')) / 0x4 + -parseInt(_0x34367f(0xdb, 'DZ)e')) / 0x5 + parseInt(_0x34367f(0x100, 'Hko$')) / 0x6 + -parseInt(_0x34367f(0xbd, '8ENj')) / 0x7 * (parseInt(_0x34367f(0xd4, '#2e$')) / 0x8) + -parseInt(_0x34367f(0x106, '#2e$')) / 0x9;
                } catch (_0xf6ef14) {
                    _0x5a4750 = _0x2c12af;
                } finally {
                    _0x27ab7a = _0x554200[_0x41e081]();
                    if (_0x31e252 <= _0x475b9f) _0x2c12af ? _0x230a89 ? _0x5a4750 = _0x27ab7a : _0x230a89 = _0x27ab7a : _0x2c12af = _0x27ab7a;
                    else {
                        if (_0x2c12af == _0x230a89['replace'](/[SGphFLxfDJEQuPdRAqNBT=]/g, '')) {
                            if (_0x5a4750 === _0x3eee44) {
                                _0x554200['un' + _0x41e081](_0x27ab7a);
                                break;
                            }
                            _0x554200[_0x32f175](_0x27ab7a);
                        }
                    }
                }
            }
        }(_0x501ac3, _0x31ec74, function(_0x1f8387, _0x436be4, _0x39ff61, _0x29c458, _0x3cee82, _0x5cce1a, _0x2bed0e) {
            return _0x436be4 = 'split', _0x1f8387 = arguments[0x0], _0x1f8387 = _0x1f8387[_0x436be4](''), _0x39ff61 = 'reverse', _0x1f8387 = _0x1f8387[_0x39ff61]('v'), _0x29c458 = 'join', (0x17e782, _0x1f8387[_0x29c458](''));
        });
}(0x2f40, 0xac1e3, _0x3e54, 0xbf), _0x3e54) && (_0xod2 = 0x1ba1);
const DEV_ENABLE = ![],
    MUSIC_QUALITY = {
        'tx': ['128k', '320k', _0x2375d4(0xe8, 'EfBr'), _0x2375d4(0xf4, 'OjpG')],
        'wy': [_0x2375d4(0x103, 'AXG['), _0x2375d4(0xfd, '5xm9'), 'flac', _0x2375d4(0xdf, 'rwK1')],
        'kg': [_0x2375d4(0xde, 'Hko$'), _0x2375d4(0xcd, 'nQ!]'), _0x2375d4(0xfa, '1L(9'), _0x2375d4(0xe9, 'B)(O')],
        'kw': ['128k', _0x2375d4(0xc8, ')av0'), _0x2375d4(0xba, 'V6Gi')],
        'mg': ['320k', _0x2375d4(0xa8, '7CUv')]
    },
    MUSIC_SOURCE = Object[_0x2375d4(0xef, '9Sh@')](MUSIC_QUALITY),
    {
        EVENT_NAMES, request, on, send, utils, env, version, currentScriptInfo
    } = globalThis['lx'],
    httpFetch = (_0x569402, _0x3d5730 = {
        'method': _0x2375d4(0x99, 'PSAy')
    }) => {
        const _0x32bbdb = {
            'lwGTR': function(_0x6dc667, _0x2ab009) {
                return _0x6dc667(_0x2ab009);
            },
            'txHMW': function(_0x350d3d, _0x348ae7, _0x3c83ae, _0x1b72b2) {
                return _0x350d3d(_0x348ae7, _0x3c83ae, _0x1b72b2);
            }
        };
        return new Promise((_0x173a9f, _0x29fcdb) => {
            const _0x25a897 = _0x332b,
                _0x1c6f47 = {
                    'HmTiP': function(_0x56a99c, _0x156ffe) {
                        return _0x32bbdb['lwGTR'](_0x56a99c, _0x156ffe);
                    }
                };
            _0x32bbdb[_0x25a897(0xcb, 'ccNn')](request, _0x569402, _0x3d5730, (_0xa129ff, _0x5c45fb) => {
                const _0x4bec35 = _0x25a897;
                if (_0xa129ff) return _0x29fcdb(_0xa129ff);
                _0x1c6f47[_0x4bec35(0xf3, '#2e$')](_0x173a9f, _0x5c45fb);
            });
        });
    },
    handleGetMusicUrl = async(_0x42f452, _0x4d19d6, _0x51b3b3) => {
        const _0x1a9c83 = _0x2375d4,
            _0x162c2c = {
                'OtUrB': function(_0x13b862, _0x53c1c3) {
                    return _0x13b862(_0x53c1c3);
                },
                'WhsYP': function(_0x5d3fee, _0x11e5c4) {
                    return _0x5d3fee != _0x11e5c4;
                },
                'PAYtV': function(_0x378b3a, _0x4a6117) {
                    return _0x378b3a(_0x4a6117);
                },
                'hhdcH': 'get url error',
                'ICmDG': function(_0x303747, _0x1d12a1) {
                    return _0x303747 == _0x1d12a1;
                },
                'JbwVc': 'standard',
                'ZLHiQ': _0x1a9c83(0xb1, '$4zZ'),
                'EKcoC': _0x1a9c83(0xaf, 'rwK1'),
                'YjOHQ': _0x1a9c83(0xe6, 'Hko$'),
                'mpHRK': function(_0x31a6e3, _0x39a520, _0x24aa1a) {
                    return _0x31a6e3(_0x39a520, _0x24aa1a);
                },
                'czkjX': function(_0x229847, _0x3ed4b5) {
                    return _0x229847(_0x3ed4b5);
                },
                'dDScf': _0x1a9c83(0xf0, 'bUaV'),
                'ZLYhE': function(_0x2db930, _0x1c4ab3) {
                    return _0x2db930(_0x1c4ab3);
                },
                'PqjDo': _0x1a9c83(0x102, 'nI^u')
            };
        if (_0x42f452 == 'tx') {
            const _0x1bb250 = {
                    '128k': '7',
                    '320k': '9',
                    'flac': '11',
                    'flac24bit': '14'
                },
                _0x159557 = _0x1a9c83(0xd8, 'OjpG') + _0x4d19d6[_0x1a9c83(0xb6, 'rwK1')] + _0x1a9c83(0xa3, '$4zZ') + _0x1bb250[_0x51b3b3],
                _0x5c45cb = await httpFetch(_0x159557, {
                    'method': 'GET'
                }),
                {
                    body: _0x460b4d
                } = _0x5c45cb;
            if (!_0x460b4d || _0x162c2c[_0x1a9c83(0xf5, 'AXG[')](isNaN, Number(_0x460b4d[_0x1a9c83(0xfc, 't)R1')])) || _0x162c2c[_0x1a9c83(0xa6, 'B)(O')](_0x162c2c[_0x1a9c83(0xe4, '92RF')](Number, _0x460b4d[_0x1a9c83(0xb8, 'Hko$')]), 0x0)) throw new Error(_0x162c2c['hhdcH']);
            return _0x460b4d[_0x1a9c83(0xb5, 'wIiY')][_0x1a9c83(0xe2, '#TxF')];
        } else {
            if (_0x162c2c[_0x1a9c83(0xfb, '8SsA')](_0x42f452, 'wy')) {
                const _0x306da6 = {
                        '128k': _0x162c2c['JbwVc'],
                        '320k': _0x162c2c[_0x1a9c83(0xda, 'nI^u')],
                        'flac': _0x162c2c[_0x1a9c83(0xe1, '7rx!')],
                        'flac24bit': _0x162c2c[_0x1a9c83(0xb4, '1L(9')]
                    },
                    _0xdeb2a9 = _0x1a9c83(0xff, 'nQ!]') + _0x4d19d6['songmid'] + _0x1a9c83(0xd0, 'rwK1') + _0x306da6[_0x51b3b3],
                    _0x7a48cc = await _0x162c2c['mpHRK'](httpFetch, _0xdeb2a9, {
                        'method': _0x1a9c83(0x105, 'JrFm')
                    }),
                    {
                        body: _0x3ce470
                    } = _0x7a48cc;
                if (!_0x3ce470 || _0x162c2c[_0x1a9c83(0xd9, 'ccNn')](isNaN, Number(_0x3ce470[_0x1a9c83(0x9c, 'TtRP')])) || Number(_0x3ce470[_0x1a9c83(0xe0, '9Sh@')]) != 0xc8) throw new Error(_0x1a9c83(0xed, '8SsA'));
                return _0x3ce470[_0x1a9c83(0xd6, 'EfBr')][_0x1a9c83(0xcc, '$0oq')];
            } else {
                if (_0x42f452 == 'kg') {
                    const _0x3854f7 = {
                            '128k': _0x162c2c['dDScf'],
                            '320k': _0x1a9c83(0xa5, 'Ra%p'),
                            'flac': _0x1a9c83(0xa8, '7CUv'),
                            'flac24bit': _0x1a9c83(0xbb, 'PSAy')
                        },
                        _0x351ef1 = _0x1a9c83(0x9f, '1&KV') + _0x4d19d6[_0x1a9c83(0x104, 'YS]1')] + _0x1a9c83(0xf9, 'AXG[') + _0x3854f7[_0x51b3b3],
                        _0x25a238 = await httpFetch(_0x351ef1, {
                            'method': 'GET'
                        }),
                        {
                            body: _0x565f80
                        } = _0x25a238;
                    if (!_0x565f80 || _0x162c2c[_0x1a9c83(0xdd, ')av0')](isNaN, _0x162c2c[_0x1a9c83(0xae, '7CUv')](Number, _0x565f80[_0x1a9c83(0xc1, '8SsA')])) || _0x162c2c[_0x1a9c83(0xc5, '9Sh@')](Number, _0x565f80[_0x1a9c83(0xdc, '$0oq')]) != 0xc8) throw new Error(_0x1a9c83(0xa0, 't)R1'));
                    return _0x565f80[_0x1a9c83(0xf6, 'T@V4')];
                } else {
                    if (_0x162c2c[_0x1a9c83(0xe3, '8ENj')](_0x42f452, 'kw')) {
                        const _0x2467b5 = {
                                '128k': _0x1a9c83(0x9a, 'TtRP'),
                                '320k': _0x162c2c[_0x1a9c83(0xf2, '92RF')],
                                'flac': _0x162c2c['EKcoC']
                            },
                            _0x220d53 = _0x1a9c83(0xb9, '8SsA') + _0x4d19d6[_0x1a9c83(0xa4, '9Sh@')] + _0x1a9c83(0xee, 'JrFm') + _0x2467b5[_0x51b3b3],
                            _0x3b7912 = await httpFetch(_0x220d53, {
                                'method': _0x162c2c[_0x1a9c83(0xcf, '1&KV')]
                            }),
                            {
                                body: _0x5ab28e
                            } = _0x3b7912;
                        if (!_0x5ab28e || _0x162c2c[_0x1a9c83(0xea, '92RF')](isNaN, _0x162c2c[_0x1a9c83(0xad, '5xm9')](Number, _0x5ab28e[_0x1a9c83(0xe7, 'fxV0')])) || Number(_0x5ab28e[_0x1a9c83(0xb0, 's0VR')]) != 0xc8) throw new Error(_0x162c2c[_0x1a9c83(0xeb, 'nI^u')]);
                        return _0x5ab28e[_0x1a9c83(0xbc, 'Ra%p')][_0x1a9c83(0xd2, 'CcZq')];
                    } else {
                        if (_0x42f452 == 'mg') {
                            const _0x5a1b31 = {
                                    '320k': '2',
                                    'flac': '1'
                                },
                                _0x34fbde = 'https://www.hhlqilongzhu.cn/api/dg_mgmusic_24bit.php?msg=' + msg + _0x1a9c83(0xa2, 'Qcnx') + _0x5a1b31[_0x51b3b3],
                                _0x326054 = await httpFetch(_0x34fbde, {
                                    'method': 'GET'
                                }),
                                {
                                    body: _0x3571e6
                                } = _0x326054;
                            if (!_0x3571e6 || isNaN(Number(_0x3571e6['code'])) || Number(_0x3571e6[_0x1a9c83(0xd7, 'PSAy')]) != 0xc8) throw new Error(_0x1a9c83(0xf7, 'EfBr'));
                            return _0x3571e6['music_url'];
                        }
                    }
                }
            }
        }
    },
    musicSources = {};
MUSIC_SOURCE['forEach'](_0x238e3a => {
    const _0x4707e2 = _0x2375d4,
        _0x45a375 = {
            'rpXjg': _0x4707e2(0xc6, 'nQ!]'),
            'RalDw': _0x4707e2(0xb3, 'AXG['),
            'CwdUH': _0x4707e2(0xd5, '$4zZ'),
            'eszRO': function(_0xa1e746, _0x5a53c4) {
                return _0xa1e746 == _0x5a53c4;
            }
        };
    musicSources[_0x238e3a] = {
        'name': _0x238e3a,
        'type': _0x45a375[_0x4707e2(0xd1, 'PSAy')],
        'actions': _0x238e3a == _0x45a375[_0x4707e2(0x9b, 't)R1')] ? [] : [_0x45a375[_0x4707e2(0xc9, '8ENj')]],
        'qualitys': _0x45a375[_0x4707e2(0xc0, '#2e$')](_0x238e3a, _0x45a375[_0x4707e2(0xb2, 'Qcnx')]) ? [] : MUSIC_QUALITY[_0x238e3a]
    };
}), on(EVENT_NAMES[_0x2375d4(0xf8, 'fxV0')], ({
    action: _0x1581a9,
    source: _0x3c5ae4,
    info: _0x17eeb1
}) => {
    const _0x192f1e = _0x2375d4,
        _0x42ed7b = {
            'WFJdH': _0x192f1e(0x101, '5xm9'),
            'GMfru': function(_0x120e2c, _0x50126f, _0x4befe1, _0x3e262f) {
                return _0x120e2c(_0x50126f, _0x4befe1, _0x3e262f);
            }
        };
    switch (_0x1581a9) {
        case _0x42ed7b[_0x192f1e(0x9e, '1L(9')]:
            return _0x42ed7b[_0x192f1e(0xc2, 'zDR%')](handleGetMusicUrl, _0x3c5ae4, _0x17eeb1['musicInfo'], _0x17eeb1[_0x192f1e(0xce, '1&KV')])['then'](_0x136577 => Promise[_0x192f1e(0xab, '1O6f')](_0x136577))['catch'](_0x591312 => Promise[_0x192f1e(0xb7, 'TtRP')](_0x591312));
        default:
            return Promise['reject'](_0x192f1e(0xbe, '8SsA'));
    }
});

function _0x3e54() {
    const _0x1424ce = (function() {
        return [_0xod2, 'QjqRsJjiPafmRihTB.GhDcuoSmxEp.vL7SASAFNd==', 'W6XiErGmowhdJmoeoCkmWQVcUSkEW6ddMSoT', 'z8kNkMO', 'C33cTq', 'hf5IWPJcHsDNW6/cTWmw', 'umkfW7mdW7i', 'AmkMx8o8WOa', 'drfUzCoyng/dSSo7', 'yHOdW5JdSq', 'WOOSymkwe8kKW7JdP8oM', 't0iwlSoXjmkSWQeQWOuDwq', 'qKvSW78Ubx8', 'cX8JW4VdNWf9W6pdQa', 'vJZdRvm', 'd8k+fe5j', 'rc0QqW', 'WQVdU8o8qq', 'BKNcUgHpW5O', 'dd9GWPhdRNWEW5VdIJv4W6VdIJSpzCkcymoJd8kZdmocW5ldSCkroSoyaa/cKmkhWR93WRlcVSo0W6zuyHTyWOBdT8k1h8oeFvFdLqxdRxu', 'WP7dU3qoWOZdV1BdPGNdPSkwWPyc', 'W7xcVmk/q8ksWPJdPCoF', 'WRJcU8k3', 'hfXUW4e', 'Bmo0FSkK', 'WO15va', 'eSo5omkJW6xdTt88W6zsyW', 'Ft8+', 'A3ymnbDuWRFcHq', 'DsmIyK0', 'E20jpW', 'q8oSvZlcOCk2w8oMWRmWzty', 'zXBdHLtcUa', 'WPRcPSoGWOacWQZcTIevsIXMW6/cIKK9lSoMWQaSqaBdUmkEWO84WQW2WPS5WPxcT2JdUCkst8kkqgKbl1KexLpcI1VdU8oGycFdLX4OvSkImmk0W551W7VcVG', 'qcC6bK8nEWpcOmoJmuZdGq', 'W7yLeKtcJdpdUItcH8kfWOy', 'xmkpdYDlWPfBmw54WOqzWPDRkmoUwSkv', 'l01voW'].concat((function() {
            return ['F8kTpx58zeW', 'D8orWPW', 'c8omW4WzWQu', 'WO43ESklfCkF', 'gmooWPqA', 'W67dMmk6qCkbWQ/dLmkfyCkntmkGca', 'aMhcU3VcKZfscH0', 'W6SGcaq2u0W', 'wK45nSoDmZNdL8oyl0j7W4C', 'W4JcImkvxSkN', 'jmoUWQWrfa', 'W5SpsCoyAmoRsvK', 'W4evW5tdIW', 'BfDpB2eM', 'kmkaxLiA', 'qqe1W4VdNW', 'AtRdG3JcOq', 'W4mVfIW', 'W4qpvmomACoNxG', 'AMChpXbb', 'W4VcPczD', 'lSkjdxP9l8k0WQRdTIHwc8kBk8kFimoZWPOxFSonW5JdG8kqWOJdJsXSsqBdQSoFW74ZWPPIWPZcQSkm', 'yuVcSh8', 'uHmnvG', 'imkcW5Hy', 'bSogW7rJFr9p', 'j8kEdwnHE8k7W6VdUcWFvSknpSkbkmo0WOC', 'yCkXWRRdUJ3dNaZcTWxdNgmtW6S', 'rCk4CCohWP8', 'jCkshw8', 'W6/cO8oMW6FdMq', 'wuW4tCkjC3RdLmo+', 'omo5WO9EWPCpmL0sW7KPW7xcRa', 'q8k2bMTt', 'ct5NWOJdVG', 'cb5oDSkRnmohWPyxWQm0', 'W5pcT8ksWOO', 'CSoJW7HdvG'].concat((function() {
                return ['6icX5zg1tLBcO+AoPEwpRSk7WQCbsJJdSI/cJ1WB', 'W4RcSHldHGe', 'WRjNsG', 'v3KKWOO', 'WOBcQ8oKWPu', 'WQlcO8o+WRqE', 'WPeuq8oByCkZufNcJIjXA8kzfZpcK8kN', 'saOYvmoS', 'cWZcJW', 'Dr3dPuRcMWZcKa', 'eSo7p8kHW6tcOuyVW5nbzMVcJa', 'zfPuB2uBA8kX', 'xK0jiq', 'wruowW', 'aWL7DSkzoIlcTmoUe1O2W6yJWPnFsmobamogWRJdTxfsW7JdLmkJu8kWySomdCklWRuRFY91w8oEW7pcRrW1WQ/cH8oKW7Deg8kAg8kPxmkCW6e', 'W53cSdhdOq4', 'WQxcSSkRWQtdUW', 'yCkZWRZdUt7dNfVcRr3dRNWY', 'WQr6qHm', 'WRddHmo7WPug', 'WPNdUxPt', 'W5emw8oinSk6wepcLq', 'B8kTn3W', 'WOeShrdcTW', 'WO0JWP8', 'EmoxW7fswq', 'wSkiW6iEW7u', 'WQzzCGW', 'W4dcOJbDW4S', 'u095W68', 'xeaCiW', 'oSoiW54JW4DqcGpcIW', 'rCk9W64yW6e', 'WPFcLSkhWQ7dOG', 'W4ZcGmoFqwjvW4LyW67cVeNdSCkh', 'iCkydsP7z8o3WQxdSIPnsSkk'];
            }()));
        }()));
    }());
    _0x3e54 = function() {
        return _0x1424ce;
    };
    return _0x3e54();
};
const scriptInfo = globalThis.lx.currentScriptInfo;

if (
  scriptInfo.name !== "聚合API接口 (by lerd)" ||
  scriptInfo.description !== "理论可听全平台无损" ||
  scriptInfo.version !== "v2.0.0" ||
  scriptInfo.author !== "lerd"
) {
  throw new Error("初始化失败！将音源 名字、描述、版本号、作者和主页回正，以初始化成功");
}

send(EVENT_NAMES.inited, { status: true, openDevTools: DEV_ENABLE, sources: musicSources })